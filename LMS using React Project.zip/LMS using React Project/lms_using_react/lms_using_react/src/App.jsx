import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CourseNavigationbar from "./coursemangement/CourseNavigationbar";
import CourseRegistration from "./coursemangement/CourseRegistration";
import CourseUpdate from "./coursemangement/CourseUpdate";
import CourseDelete from "./coursemangement/CourseDelete";
import CourseList from "./coursemangement/CourseList";
import CourseDetails from "./coursemangement/CourseDetails";
import ModuleCreation from "./coursemangement/ModuleCreation";
import FacultyAssignment from "./coursemangement/FacultyAssignment";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/register" element={<CourseRegistration />} />
        <Route path="/update" element={<CourseUpdate />} />
        <Route path="/delete" element={<CourseDelete />} />
        <Route path="/list" element={<CourseList />} />
        <Route path="/details" element={<CourseDetails />} />
        <Route path="/modules" element={<ModuleCreation />} />
        <Route path="/faculty" element={<FacultyAssignment />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;