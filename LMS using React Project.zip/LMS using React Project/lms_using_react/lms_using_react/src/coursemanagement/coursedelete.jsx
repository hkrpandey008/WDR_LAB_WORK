import React from "react";

const CourseDelete = () => {
  return (
    <div>
      <h2>Course Delete</h2>
      <p>Delete a course by ID.</p>
    </div>
  );
};

export default CourseDelete;