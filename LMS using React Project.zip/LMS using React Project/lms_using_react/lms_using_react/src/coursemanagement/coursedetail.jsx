import React from "react";

const CourseDetails = () => {
  return (
    <div>
      <h2>Course Details</h2>
      <p>View detailed course information here.</p>
    </div>
  );
};

export default CourseDetails;