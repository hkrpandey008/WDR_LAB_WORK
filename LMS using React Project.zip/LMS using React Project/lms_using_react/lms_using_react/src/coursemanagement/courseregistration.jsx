import React, { useState } from "react";

const CourseRegistration = () => {
  const [course, setCourse] = useState({
    name: "",
    duration: "",
    faculty: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Course Registered:", course);
  };

  return (
    <div>
      <h2>Course Registration</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Course Name"
               onChange={(e) => setCourse({ ...course, name: e.target.value })} />

        <input placeholder="Duration"
               onChange={(e) => setCourse({ ...course, duration: e.target.value })} />

        <input placeholder="Faculty"
               onChange={(e) => setCourse({ ...course, faculty: e.target.value })} />

        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default CourseRegistration;