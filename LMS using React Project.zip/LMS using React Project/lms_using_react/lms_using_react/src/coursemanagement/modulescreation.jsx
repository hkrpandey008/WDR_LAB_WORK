import React from "react";

const ModuleCreation = () => {
  return (
    <div>
      <h2>Module Creation</h2>
      <p>Create modules for any course here.</p>
    </div>
  );
};

export default ModuleCreation;