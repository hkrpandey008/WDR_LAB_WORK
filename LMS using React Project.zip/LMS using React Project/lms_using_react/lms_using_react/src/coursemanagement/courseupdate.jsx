import React from "react";

const CourseUpdate = () => {
  return (
    <div>
      <h2>Course Update</h2>
      <p>Update an existing course here.</p>
    </div>
  );
};

export default CourseUpdate;