import React from "react";

const FacultyAssignment = () => {
  return (
    <div>
      <h2>Faculty Assignment</h2>
      <p>Assign faculty to a course.</p>
    </div>
  );
};

export default FacultyAssignment;