import React from "react";

const CourseList = () => {
  const dummyCourses = [
    { id: 1, name: "HTML Basics" },
    { id: 2, name: "JavaScript Mastery" }
  ];

  return (
    <div>
      <h2>Course List</h2>
      <ul>
        {dummyCourses.map(c => (
          <li key={c.id}>{c.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default CourseList;