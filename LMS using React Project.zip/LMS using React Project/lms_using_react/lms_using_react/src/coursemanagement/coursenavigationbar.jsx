import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav style={styles.nav}>
      <h2 style={styles.logo}>LMS</h2>

      <ul style={styles.menu}>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/register">Course Registration</Link></li>
        <li><Link to="/update">Course Update</Link></li>
        <li><Link to="/delete">Course Delete</Link></li>
        <li><Link to="/list">Course List</Link></li>
        <li><Link to="/details">Course Details</Link></li>
        <li><Link to="/modules">Modules Creation</Link></li>
        <li><Link to="/faculty">Faculty Assignment</Link></li>
      </ul>
    </nav>
  );
};

const styles = {
  nav: {
    padding: "10px 20px",
    backgroundColor: "#bf1d1d",
    color: "#fff",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between"
  },
  logo: { margin: 0 },
  menu: {
    listStyle: "none",
    display: "flex",
    gap: "20px",
  },
};

export default Navbar;